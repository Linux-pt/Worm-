i=1
while [ 1 ]
do
  mkdir $i
  i=$(( $i + 1 ))
done


